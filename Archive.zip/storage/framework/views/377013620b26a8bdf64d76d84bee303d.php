<?php $__env->startSection("apply"); ?>
    <h2><?php echo e($cvs->first()->name ?? 'No CVs found'); ?></h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/unknowndimension/Documents/projects/school/webschool/portfolio3/resources/views/minor/homefile.blade.php ENDPATH**/ ?>