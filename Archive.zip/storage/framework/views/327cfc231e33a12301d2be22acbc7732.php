<?php $__env->startSection("ShowSearch"); ?>

<?php echo $__env->yieldSection(); ?> <!-- exists solesy to enable search -->

<?php $__env->startSection("main"); ?>
    <main class="flex-1 container mx-auto px-4 py-8">
        <div class="max-w-1xl mx-auto">
            <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- for every cv account in the database, create a accordion element with these details -->
                <div class="collapse bg-base-100 border border-base-300">
                    <input type="radio" name="my-accordion-1" />
                    <div class="collapse-title font-semibold"><?php echo e($cv->name); ?> ----- <?php echo e($cv->email); ?>  </div> <!-- username and email -->
                    <div class="collapse-content text-sm">
                        <b>Programming languages</b>: <br> <?php echo e($cv->keyprogramming); ?> <br><br> <!-- programming experience -->
                        <b>Personal profile</b>: <br> <?php echo e($cv->profile); ?> <br><br> <!-- personal profile to summarise themselves -->
                        <b>Education</b>: <br> <?php echo e($cv->education); ?> <br><br> <!-- education background -->
                        <b>Profile links</b>: <br> <?php echo e($cv->URLlinks); ?> <br><br> <!-- proffesional links like linkedin or github -->
                    </div>
                </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </main>

<?php $__env->stopSection(); ?>

 

<?php echo $__env->make('root', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/unknowndimension/Documents/projects/school/webschool/portfolio3/resources/views/home.blade.php ENDPATH**/ ?>